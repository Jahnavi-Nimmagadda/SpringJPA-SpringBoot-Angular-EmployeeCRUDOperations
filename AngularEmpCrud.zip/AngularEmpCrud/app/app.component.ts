import { Component, OnInit } from '@angular/core';

import { of, Observable, OperatorFunction } from 'rxjs';
import { map} from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { EmployeeserviceService, Employee } from './employeeservice.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent  implements OnInit{
  title = 'employee-project';

  service:EmployeeserviceService;
  constructor(service:EmployeeserviceService){
    this.service=service;
  }

  ngOnInit(){
    this.service.fetchEmployees();
  }
}

